import UIKit

protocol VehicleDetalis {
    var name : String { get set }
    var manufacturingYear : Int { get set }
    func descriptionV()
}
public class Vehicle : VehicleDetalis {
    var manufacturingYear : Int
    var vehicleColor : String
    var name : String
    
    init(manufacturingYear : Int , vehicleColor : String , name : String){
        self.name = name
        self.manufacturingYear = manufacturingYear
        self.vehicleColor = vehicleColor
    }
    
     func descriptionV(){
        print("Your car is \(self.name) and manufacturing Year was: \(self.manufacturingYear) with color of: \(self.vehicleColor) ")
        
    }
    
} // dn
class Electerc : Vehicle{
    var numberOfBatteries : Int
    var theRange : Double
    
    init(numberOfBatteries : Int , theRange : Double , manufacturingYear:Int , vehicleColor:String , name:String){
        self.numberOfBatteries = numberOfBatteries
        self.theRange = theRange
        super.init(manufacturingYear: manufacturingYear, vehicleColor: vehicleColor, name: name)
    }
    
    override func descriptionV() {
        print("Your car is \(self.name) and manufacturing Year: \(self.manufacturingYear) with color of \(self.vehicleColor) \nits come with \(self.numberOfBatteries) Batteries and \(self.theRange) KM Rang")
    }
    
}//dn
class rechargeabl : Electerc {
    var chargeHour: Double
    var kindOfBatterie : String
    
    init(chargeHour: Double , kindOfBatterie : String , numberOfBatteries:Int , theRange:Double , manufacturingYear: Int , vehicleColor:String , name: String){
        self.chargeHour = chargeHour
        self.kindOfBatterie = kindOfBatterie
        super.init(numberOfBatteries: numberOfBatteries, theRange: theRange, manufacturingYear: manufacturingYear, vehicleColor: vehicleColor, name: name)
    }
    
    override func descriptionV() {
        print("Your car \(self.name) and the manufacturing Year: \(self.manufacturingYear) with color of \(self.vehicleColor) ,its come with \(self.numberOfBatteries) Batteries and takes about \(self.chargeHour)hours to charge \nyour car rang about \(self.theRange)KM and the kind of Batteries : \(self.kindOfBatterie)")
    }
    
    
} // dn
class Hybrid  : Electerc {
    var kindOfHybrid : String
    
    init(kindOfHybrid : String , numberOfBatteries: Int , theRange: Double , manufacturingYear: Int , vehicleColor: String , name: String  ){
        self.kindOfHybrid = kindOfHybrid
        super.init(numberOfBatteries: numberOfBatteries, theRange: theRange, manufacturingYear: manufacturingYear, vehicleColor: vehicleColor, name: name)
    }
    override func descriptionV() {
        print("Your car \(self.name) and the manufacturing Year: \(self.manufacturingYear) with color of \(self.vehicleColor) ,its come with \(self.kindOfHybrid) Engine Kind \nyour car rang about \(self.theRange)KM.")
    }
    
    
}//dn
class Engine : Vehicle {
    var numberOfCylinders : Int
    var engineCapacity : Double
    
    
    init(manufacturingYear: Int ,numberOfCylinders : Int, engineCapacity : Double , vehicleColor : String , name : String){
        self.numberOfCylinders = numberOfCylinders
        self.engineCapacity = engineCapacity
        super.init( manufacturingYear: manufacturingYear, vehicleColor: vehicleColor,name:name )
    }
    
    override func descriptionV() {
        print("Your car manufacturing Year: \(self.manufacturingYear) with color of \(self.vehicleColor) ,its come with \(self.numberOfCylinders) Cylinder and  \(self.engineCapacity) Liter ")
    }
    
} // dn
class Turbo : Engine {
    var kindOfTurbo : String
    var price : Float
    
    init(kindOfTurbo : String , price : Float , manufacturingYear: Int , numberOfCylinders: Int, engineCapacity: Double , vehicleColor: String , name : String){
        self.kindOfTurbo = kindOfTurbo
        self.price = price
        super.init(manufacturingYear: manufacturingYear, numberOfCylinders: numberOfCylinders, engineCapacity: engineCapacity, vehicleColor: vehicleColor , name : name  )
    }
    
    override func descriptionV() {
        print("Your car \(self.name) and the manufacturing Year: \(self.manufacturingYear) with color of \(self.vehicleColor) ,its come with \(self.numberOfCylinders) Cylinder and  \(self.engineCapacity) Liter \nyour car comes with Turbo (\(self.kindOfTurbo)) and the cost for it : \(self.price)")
    }
    
    
} // dn
class Supercharged : Engine {
    var kindOfSupercharged : String
    var price : Float
    
    init(kindOfSupercharged  : String , price : Float , manufacturingYear: Int , numberOfCylinders: Int, engineCapacity: Double , vehicleColor: String ,name : String){
        self.kindOfSupercharged  = kindOfSupercharged
        self.price = price
        super.init(manufacturingYear: manufacturingYear, numberOfCylinders: numberOfCylinders, engineCapacity: engineCapacity, vehicleColor: vehicleColor , name: name)
    }
    
    override func descriptionV() {
        print("Your car is \(self.name) and the manufacturing Year: \(self.manufacturingYear) with color of \(self.vehicleColor) ,its come with \(self.numberOfCylinders) Cylinder and  \(self.engineCapacity) Liter \nyour car comes with Turbo (\(self.kindOfSupercharged )) and the cost for it : \(self.price)")
    }
} // dn



protocol EmployeeDetalis{
    var empolyeeName: String {get set}
    var age : Int {get set}
    var jops : [String] {get set}
}
public class Employee : EmployeeDetalis {
  var empolyeeName: String
  var age : Int
  var jops : [String] = ["Developer" , "Accountant" , "Engineer" , "Technical"]

  init(empolyeeName: String , age : Int) {
    self.empolyeeName = empolyeeName
    self.age = age
  }

    func descriptionE() {
        print("Hello! I am new Employee , my name is \(self.empolyeeName) and I am \(self.age)")

  }
}
class Developer: Employee {
  var favoriteLanguage: String

    init(empolyeeName: String, favoriteLanguage: String , age :Int) {
    self.favoriteLanguage = favoriteLanguage
    super.init(empolyeeName: empolyeeName , age: age)
  }
    override func descriptionE() {
        print("Hello! I am a Developer! My name is \(self.empolyeeName) and I am \(self.age)")
  }
}

private class Swift:Developer{
 
    override init(empolyeeName: String, favoriteLanguage: String, age: Int) {
        super.init(empolyeeName: empolyeeName, favoriteLanguage: favoriteLanguage, age: age)
    }
    override func descriptionE() {
        print("Hi!! , my name is : \(self.empolyeeName), I am \(self.age) years and my favorite Language is: \(self.favoriteLanguage)")
    }
}
private class Java:Developer{
    override init(empolyeeName: String, favoriteLanguage: String, age: Int) {
        super.init(empolyeeName: empolyeeName, favoriteLanguage: favoriteLanguage, age: age)
    }
    override func descriptionE() {
        print("Hi!! , my name is : \(self.empolyeeName), I am \(self.age) years and my favorite Language is: \(self.favoriteLanguage)")
    }
}
private class JavaScripte:Developer{
    override init(empolyeeName: String, favoriteLanguage: String, age: Int) {
        super.init(empolyeeName: empolyeeName, favoriteLanguage: favoriteLanguage, age: age)
    }
    override func descriptionE() {
        print("Hi!! , my name is : \(self.empolyeeName), I am \(self.age) years and my favorite Language is: \(self.favoriteLanguage)")
    }
}
private class Fullter:Developer{
    override init(empolyeeName: String, favoriteLanguage: String, age: Int) {
        super.init(empolyeeName: empolyeeName, favoriteLanguage: favoriteLanguage, age: age)
    }
    override func descriptionE() {
        print("Hi!! , my name is : \(self.empolyeeName), I am \(self.age) years and my favorite Language is: \(self.favoriteLanguage)")
    }
}


class Accountant : Employee{
    var companyAccount: String
    var bankAccount : String

      init(empolyeeName: String, companyAccount: String , age :Int , bankAccount : String) {
      self.companyAccount = companyAccount
      self.bankAccount = bankAccount
      super.init(empolyeeName: empolyeeName , age: age)
    }
      override func descriptionE() {
          print("Hello! I am a Accountant! My name is \(self.empolyeeName) and I am \(self.age)\nThe Company banck account: \(self.companyAccount)\nMy Bank Account: \(self.bankAccount)  ")
    }

}
class Engineer  : Employee{
    var workFilde : String
    let specialist : String
    
    init(workFilde : String , specialist : String , empolyeeName:String , age:Int ){
        self.workFilde = workFilde
        self.specialist = specialist
        super.init(empolyeeName: empolyeeName, age: age)
    }
    
    override func descriptionE() {
        print("Hello! I am a Engineer! My name is \(self.empolyeeName) and I am \(self.age)\nMy filde work: \(self.workFilde)\nMy specialist: \(self.specialist)  ")
    }
    
    
    
}

class Mechanical : Engineer{
    
    
    
}

class Chemical : Engineer{
    
    
}

class petroleum : Engineer{
    
    
}

class Technical : Employee{
    var workFilde : String
    let specialist : String
    
    init(workFilde : String , specialist : String , empolyeeName:String , age:Int ){
        self.workFilde = workFilde
        self.specialist = specialist
        super.init(empolyeeName: empolyeeName, age: age)
    }
    
    override func descriptionE() {
        print("Hello! I am a Technical! My name is \(self.empolyeeName) and I am \(self.age)\nMy filde work: \(self.workFilde)\nMy specialist: \(self.specialist)  ")
    }

}





protocol SportsDetalis{
    var numberOfPlayers : Int {get set}
    var kindOfSport : String {get set}
    func descriptionS()
}


public class Sport : SportsDetalis{
    
    var numberOfPlayers: Int
    var kindOfSport: String
    
    
    init( numberOfPlayers: Int , kindOfSport: String ){
        self.kindOfSport = kindOfSport
        self.numberOfPlayers = numberOfPlayers
    }
    
    func descriptionS() {
        print("any description")
    }
    
    
}


class TeamSport : Sport {
    var kind : String
    var time : Double
    
    
    
    init(kind : String,time : Double ,  numberOfPlayers:Int , kindOfSport : String ){
        self.time = time
        self.kind = kind
        super.init(numberOfPlayers: numberOfPlayers, kindOfSport: kindOfSport)
        
    }
    
    enum NameOfSport {
        case football
        case basketball
        case volleyball
        case handball
   
        func theSport() -> String{
            switch self{
            case.basketball:
                return "Hi! your favorite Sport is basketball "
            case .football:
                return "Hi! your favorite Sport is football "
            case .volleyball:
                return "Hi! your favorite Sport is volleyball "
            case .handball:
                return "Hi! your favorite Sport is handball "
            }
        }
        
        
    }
    
    override func descriptionS() {
        print("the sport kind is : \(self.kind) and the time to play is :\(self.time) and sport name is:\(NameOfSport.football) with number of player: \(self.numberOfPlayers) ")
    }
    
}
private class Football : TeamSport {
    let playerNumber : Int
    let playerName : String
    let teamName : String
    
    init(teamName : String,playerNumber : Int , playerName : String , kind:String , time: Double,numberOfPlayers: Int , kindOfSport: String){
        self.playerNumber = playerNumber
        self.teamName = teamName
        self.playerName = playerName
        super.init(kind: kind, time: time, numberOfPlayers: numberOfPlayers, kindOfSport: kindOfSport)
        
    }
    
    override func descriptionS() {
        print("It Football!! , and team name is \(self.teamName)")
    }
    
    
    
}
private class Basketball : TeamSport {
    let playerNumber : Int
    let playerName : String
    let teamName : String
    
    init(teamName : String,playerNumber : Int , playerName : String , kind:String , time: Double,numberOfPlayers: Int , kindOfSport: String){
        self.playerNumber = playerNumber
        self.teamName = teamName
        self.playerName = playerName
        super.init(kind: kind, time: time, numberOfPlayers: numberOfPlayers, kindOfSport: kindOfSport)
        
    }
    
    override func descriptionS() {
        print("It Basketball!! , and team name is \(self.teamName)")
    }
}
private class Volleyball : TeamSport {
    let playerNumber : Int
    let playerName : String
    let teamName : String
    
    init(teamName : String,playerNumber : Int , playerName : String , kind:String , time: Double,numberOfPlayers: Int , kindOfSport: String){
        self.playerNumber = playerNumber
        self.teamName = teamName
        self.playerName = playerName
        super.init(kind: kind, time: time, numberOfPlayers: numberOfPlayers, kindOfSport: kindOfSport)
        
    }
    
    override func descriptionS() {
        print("It Volleyball!! , and team name is \(self.teamName)")
    }
}
private class Handball : TeamSport {
    let playerNumber : Int
    let playerName : String
    let teamName : String
    
    init(teamName : String,playerNumber : Int , playerName : String , kind:String , time: Double,numberOfPlayers: Int , kindOfSport: String){
        self.playerNumber = playerNumber
        self.teamName = teamName
        self.playerName = playerName
        super.init(kind: kind, time: time, numberOfPlayers: numberOfPlayers, kindOfSport: kindOfSport)
        
    }
    
    override func descriptionS() {
        print("It Handball!! , and team name is \(self.teamName)")
    }
}





 class singleSport : Sport {
    var time : Double
     var dictionaryOfSport = [2: "Tennis",
                             2: "billiard",
                             1: "Cycling",
                             2: "Table Tennis"]
    
    
     init(dictionaryOfSport : [Int:String],time : Double ,  numberOfPlayers:Int , kindOfSport : String ){
        self.time = time
        self.dictionaryOfSport = dictionaryOfSport
        super.init(numberOfPlayers: numberOfPlayers, kindOfSport: kindOfSport)
        
    }
    
    
    override func descriptionS() {
        print("thir are lots of Single Sport such as \(dictionaryOfSport)")
    }
    
}

final class Tennis:singleSport{
    override init(dictionaryOfSport: [Int:String] , time: Double , numberOfPlayers:Int , kindOfSport: String){
        super.init(dictionaryOfSport: dictionaryOfSport, time: time, numberOfPlayers: numberOfPlayers, kindOfSport: kindOfSport)
    }
    
    
    
    
    override func descriptionS() {
        print("it is \(self.dictionaryOfSport) , and the time to finis it \(self.time) with number of players \(self.numberOfPlayers) , and the kind of this sport is \(self.kindOfSport)")
    }
}
final class Billiard:singleSport{
    override init(dictionaryOfSport: [Int:String] , time: Double , numberOfPlayers:Int , kindOfSport: String){
        super.init(dictionaryOfSport: dictionaryOfSport, time: time, numberOfPlayers: numberOfPlayers, kindOfSport: kindOfSport)
    }
    
    
    
    
    override func descriptionS() {
        print("it is \(self.dictionaryOfSport) , and the time to finis it \(self.time) with number of players \(self.numberOfPlayers) , and the kind of this sport is \(self.kindOfSport)")
    }
}
final class Cycling:singleSport{
    override init(dictionaryOfSport: [Int:String] , time: Double , numberOfPlayers:Int , kindOfSport: String){
        super.init(dictionaryOfSport: dictionaryOfSport, time: time, numberOfPlayers: numberOfPlayers, kindOfSport: kindOfSport)
    }
    
    override func descriptionS() {
        print("it is \(self.dictionaryOfSport) , and the time to finis it \(self.time) with number of players \(self.numberOfPlayers) , and the kind of this sport is \(self.kindOfSport)")
    }
}
final class TableTennis:singleSport{
    override init(dictionaryOfSport: [Int:String] , time: Double , numberOfPlayers:Int , kindOfSport: String){
        super.init(dictionaryOfSport: dictionaryOfSport, time: time, numberOfPlayers: numberOfPlayers, kindOfSport: kindOfSport)
}




override func descriptionS() {
    print("it is \(self.dictionaryOfSport) , and the time to finis it \(self.time) with number of players \(self.numberOfPlayers) , and the kind of this sport is \(self.kindOfSport)")
}
}

class FitnessSports : Sport{
    var time : Double
    var arrayOfSports1 : [String] = ["Olympic swimming" , "boxing" , "Weight lifting" , "Table Tennis", "running"]
    
    
    init(arrayOfSports1 : [String],time : Double ,  numberOfPlayers:Int , kindOfSport : String ){
        self.time = time
        self.arrayOfSports1 = arrayOfSports1
        super.init(numberOfPlayers: numberOfPlayers, kindOfSport: kindOfSport)
        
    }
    
    
    override func descriptionS() {
        print("thir are lots of Single Sport such as \(arrayOfSports1)")
    }
    
    
}





print("_____________________________________________________________________")

var allKeyWord : [Any] = ["Class"  ,  "deinit"  ,"enum" ,   "extension" ,   "fileprivate" ,    "func" ,   "import" , "inout" , "nternal  ",  "let",    "open" ,   "operator" ,   "private"  ,  "precedencegroup" , "public",    "rethrows"  ,  "static",    "struct" ,   "subscript"  ,  "typealias" ,   "var" , "break"  ,  "case"  ,  "catch"  ,  "continue"  ,  "default"  ,  "defer" , "do"  ,  "else"  ,  "fallthrough"  ,  "for" ,   "guard"  ,  "if",
                          "in"   , "repeat"  ,  "return"  ,  "throw"  ,  "switch","where"   , "while",
    "Any"  ,  "as"  ,  "catch" ,   "false"  ,  "is" , "nil"  ,  "rethrows"  ,"self",  "Self"  ,  "super" ,"throw"   , "throws" ,   "true" ,   "try" ,
    "associativity" ,   "convenience"  ,  "didSet"   , "dynamic"   , "final"  ,  "get"    ,"indirect"  ,  "infix"  ,  "lazy" , "left" ,   "mutating"  ,  "none"  ,  "nonmutating"  ,  "optional"   , "override"   , "postfix" ,   "precedence"  ,  "prefix",
                          "Protocol" ,   "required" ,   "right" ,   "set" ,   "some"   , "Type" ,   "unowned" ,   "weak"  ,  "willSet" ,
                          "#available" ,   "#colorLiteral"  ,  "#column"  ,  "#dsohandle",    "#elseif" ,   "#else"  ,  "#endif" ,
                          "#error"  ,  "#fileID"   , "#fileLiteral"  ,  "#filePath",    "#file"  ,  "#function"  ,  "#if" , "#imageLiteral"   , "#keyPath"   , "#line"  ,  "#selector" ,   "#sourceLocation" ,   "#warning"]



print(allKeyWord.count)














